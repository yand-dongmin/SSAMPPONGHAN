require("dotenv").config();

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const cloudinary = require('cloudinary').v2;
const { CloudinaryStorage } = require('multer-storage-cloudinary');

const app = express();
app.use(express.json());
app.use(cors()); // CORS 설정

app.get('/favicon.ico', (req, res) => {
  res.sendFile(path.join(__dirname, 'path_to_your_favicon.ico'));
});

// MongoDB 연결 설정
const dbConnect = require("./src/config/dbConnect");
dbConnect();

// 사용자 스키마 정의
const userSchema = new mongoose.Schema({
  email: String,
  password: String,
  phone: String,
  profileImage: String, // 사용자 프로필 이미지 URL 추가
});

// 사용자 모델 생성
const User = mongoose.model('User', userSchema);

// 사용자 등록 API
app.post('/api/users', async (req, res) => {
  const { email, password, phone } = req.body;

  if (!email || !password || !phone) {
    return res.status(400).json({ message: 'All fields are required.' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({ email, password: hashedPassword, phone });
    await newUser.save();
    return res.status(201).json({ message: 'User registered successfully!' });
  } catch (error) {
    console.error('Error saving user:', error);
    return res.status(500).json({ message: 'Failed to register user' });
  }
});

app.post('/api/users/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required.' });
  }

  try {
    const user = await User.findOne({ email });
    if (!user) {
      console.log('No user found with email:', email);
      return res.status(401).json({ message: 'Invalid email or password.' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid email or password.' });
    }

    return res.status(200).json({ message: 'Login successful' });
  } catch (error) {
    console.error('Error during login:', error);
    return res.status(500).json({ message: 'Login failed' });
  }
});

// .env 파일에서 CLOUDINARY_URL 환경 변수를 불러와 설정
cloudinary.config({
  url: process.env.CLOUDINARY_URL,  // .env에서 CLOUDINARY_URL 사용
});

// Multer-Cloudinary 스토리지 설정
const storage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: {
    folder: 'user-uploads', // Cloudinary 폴더 이름
    format: async (req, file) => 'jpg', // 업로드 파일 형식
    public_id: (req, file) => file.originalname, // 파일 이름
  },
});

const upload = multer({ storage });

// 이미지 업로드 API
app.post('/api/upload', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded.' });
    }
    const imageUrl = req.file.path; // Cloudinary에서 생성된 URL
    return res.status(200).json({ message: 'Image uploaded successfully!', imageUrl });
  } catch (error) {
    console.error('Error uploading image:', error);
    return res.status(500).json({ message: 'Image upload failed.', error: error.message });
  }
});

// Product 스키마 정의 (이미지 URL, 카테고리, 타입, name)
const productSchema = new mongoose.Schema({
  imageUrl: String,
  category: String,
  type: String, // 예: coat, jacket, 등
  name: String, // 자동으로 생성된 name
});

// name을 자동으로 생성하는 pre-save 훅
productSchema.pre('save', function(next) {
  if (this.category && this.type) {
    // 현재 날짜와 시간을 가져오기
    const now = new Date();
    const month = String(now.getMonth() + 1).padStart(2, '0'); // 월 (0부터 시작하므로 +1)
    const day = String(now.getDate()).padStart(2, '0'); // 날짜
    const hours = String(now.getHours()).padStart(2, '0'); // 시간
    const minutes = String(now.getMinutes()).padStart(2, '0'); // 분

    // category와 type을 결합하고, 현재 날짜/시간을 기반으로 name을 설정
    this.name = `${this.category.charAt(0)}${this.type.charAt(0)}${month}${day}${hours}${minutes}`;
  }
  next();
});

const Product = mongoose.model('Product', productSchema);

// 제품 저장 API
app.post('/api/saveProduct', async (req, res) => {
  const { imageUrl, category, type } = req.body;

  if (!imageUrl || !category || !type) {
    return res.status(400).json({ message: 'All fields are required.' });
  }

  try {
    const newProduct = new Product({
      imageUrl,
      category,
      type
    });

    await newProduct.save();
    return res.status(201).json({ message: 'Product saved successfully!', product: newProduct });
  } catch (error) {
    console.error('Error saving product:', error);
    return res.status(500).json({ message: 'Failed to save product' });
  }
});

// 서버 시작
app.listen(3001, () => {
  console.log('Server is running on http://localhost:3001');
});
