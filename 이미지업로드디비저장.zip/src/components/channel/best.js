import React from 'react';
import './channel.css'
import { useNavigate } from 'react-router-dom'; //라우팅


function Best() {

  const navigate = useNavigate(); // 버튼 클릭 시 페이지 이동 라우터
  
  return (
      <div className="container">
        <div className='product-location-column'>
            <div className='product-location-row'>
              <div className='product-item' onClick={() =>{navigate('/');}}>
                <img src="https://res.cloudinary.com/dlmsuatxl/image/upload/v1733052295/user-uploads/coment.png.jpg" alt="Outfit 1" />
                <p className='product-nameprice'>dote</p>
                <p className='product-nameprice'>15000</p>
              </div>
              <div className='product-item' onClick={() =>{navigate('/');}}>
                <img src="/images/exex.png" alt="Outfit 1" />
                <p className='product-nameprice'>dote</p>
                <p className='product-nameprice'>15000</p>
              </div>
              <div className='product-item' onClick={() =>{navigate('/');}}>
                <img src="/images/exex.png" alt="Outfit 1" />
                <p className='product-nameprice'>dote</p>
                <p className='product-nameprice'>15000</p>
              </div>
            </div>
            <div className='product-location-row'>
              <div className='product-item' onClick={() =>{navigate('/');}}>
                <img src="/images/exex.png" alt="Outfit 1" />
                <p className='product-nameprice'>dote</p>
                <p className='product-nameprice'>15000</p>
              </div>
              <div className='product-item' onClick={() =>{navigate('/');}}>
                <img src="/images/exex.png" alt="Outfit 1" />
                <p className='product-nameprice'>dote</p>
                <p className='product-nameprice'>15000</p>
              </div>
              <div className='product-item' onClick={() =>{navigate('/');}}>
                <img src="/images/exex.png" alt="Outfit 1" />
                <p className='product-nameprice'>dote</p>
                <p className='product-nameprice'>15000</p>
              </div>
            </div>
          </div>
      </div>
  );
}

export default Best;
