import React, { useState } from "react";
import axios from "axios";

function ProductSelector() {
  const [image, setImage] = useState(null); // 업로드된 이미지 URL
  const [loading, setLoading] = useState(false);
  const [category, setCategory] = useState("outer"); // 선택된 카테고리 상태
  const [type, setType] = useState(""); // 선택된 아이템

  const handleImageUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("image", file); // 서버에서 'image'로 받아야 함

    try {
      setLoading(true);
      const response = await axios.post("http://localhost:3001/api/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      setImage(response.data.imageUrl); // 서버에서 반환된 이미지 URL
      setLoading(false);
    } catch (error) {
      console.error("Error uploading image:", error);
      setLoading(false);
    }
  };

  const handleSaveProduct = async () => {
    if (!image || !category || !type) {
      alert("모든 필드를 입력하세요!");
      return;
    }

    try {
      const response = await axios.post("http://localhost:3001/api/saveProduct", {
        imageUrl: image,
        category: category,
        type: type
      });
      alert(response.data.message); // 성공 시 메시지
      console.log(response.data.product); // 저장된 제품 확인
    } catch (error) {
      console.error("Error saving product:", error);
      alert("Failed to save product");
    }
  };

  const renderRadioButtons = () => {
    if (category === "outer") {
      return (
        <div>
          <label>
            <input type="radio" name="outer" value="coat" onChange={(e) => setType(e.target.value)} />
            Coat
          </label>
          <label>
            <input type="radio" name="outer" value="jacket" onChange={(e) => setType(e.target.value)} />
            Jacket
          </label>
          <label>
            <input type="radio" name="outer" value="parka" onChange={(e) => setType(e.target.value)} />
            Parka
          </label>
        </div>
      );
    } else if (category === "top") {
      return (
        <div>
          <label>
            <input type="radio" name="top" value="cardigan" onChange={(e) => setType(e.target.value)} />
            Cardigan
          </label>
          <label>
            <input type="radio" name="top" value="hoodies" onChange={(e) => setType(e.target.value)} />
            Hoodies
          </label>
          <label>
            <input type="radio" name="top" value="shirt" onChange={(e) => setType(e.target.value)} />
            Shirt
          </label>
        </div>
      );
    }
    // ... 다른 카테고리 처리
  };

  return (
    <div>
      <h2>Upload and Display Image</h2>
      <input type="file" onChange={handleImageUpload} />
      {loading && <p>Uploading...</p>}
      {image && <img src={image} alt="Uploaded" style={{ maxWidth: "100%" }} />}

      <h2>Select Category</h2>
      <select onChange={(e) => setCategory(e.target.value)} value={category}>
        <option value="outer">OUTER</option>
        <option value="top">TOP</option>
        <option value="bottom">BOTTOM</option>
        <option value="shoes">SHOES</option>
      </select>

      {renderRadioButtons()}

      <button onClick={handleSaveProduct}>Save Product</button>
    </div>
  );
}

export default ProductSelector;
