// server.js
require("dotenv").config();

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors()); // CORS 설정

// MongoDB 연결 설정
const dbConnect = require("./src/config/dbConnect");
dbConnect();

// 사용자 스키마 정의
const userSchema = new mongoose.Schema({
  email: String,
  pw: String,
  phone: String,
});

// 사용자 모델 생성
const User = mongoose.model('User', userSchema);

// 사용자 등록 API
app.post('/api/users', async (req, res) => {
  const { email, pw, phone } = req.body;

  // 유효성 검사 추가
  if (!email || !pw || !phone) {
    return res.status(400).json({ message: 'All fields are required.' });
  }

  try {
    const newUser = new User({ email, pw, phone });
    await newUser.save();
    return res.status(201).json({ message: 'User registered successfully!' });
  } catch (error) {
    console.error('Error saving user:', error); // 에러 메시지 출력
    return res.status(500).json({ message: 'Failed to register user' });
  }
});

// 서버 시작
app.listen(3001, () => {
  console.log('Server is running on http://localhost:3001');
});
