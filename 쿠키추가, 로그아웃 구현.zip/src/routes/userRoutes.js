const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const User = require('../components/models/users'); // MongoDB의 User 모델

// 회원 가입 데이터 저장을 위한 엔드포인트
router.post('/', async (req, res) => {
    const { email, password, phone } = req.body;

    try {
        // 비밀번호 해시화
        const hashedPassword = await bcrypt.hash(password, 10);

        // 새로운 사용자 데이터 생성
        const newUser = new User({
            email,
            password: hashedPassword, // 해시화된 비밀번호 저장
            phone,
        });

        // 데이터베이스에 저장
        await newUser.save();
        res.status(201).json({ message: 'User saved successfully!' });
    } catch (error) {
        console.error('Error saving user:', error);
        res.status(500).json({ message: 'Error saving user to the database' });
    }
});

// 로그인 API
router.post('/login', async (req, res) => {
    const { email, password } = req.body; // 클라이언트에서 이메일과 비밀번호 받기
    
    try {
      // 이메일로 사용자 찾기
      const user = await User.findOne({ email });
      if (!user) {
        return res.status(401).json({ message: "이메일 또는 비밀번호가 일치하지 않습니다." });
      }

      // bcrypt로 저장된 비밀번호와 입력된 비밀번호 비교
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(401).json({ message: "이메일 또는 비밀번호가 일치하지 않습니다." });
      }

      // 로그인 성공 응답
      res.json({ message: "로그인 성공", user: { email: user.email } });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
});

module.exports = router;
