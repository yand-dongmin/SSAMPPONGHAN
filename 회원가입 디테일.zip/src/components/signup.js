import React, { useState } from 'react';
import './signup.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Signup() {
    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [pw, setPw] = useState('');
    const [pwc, setPwc] = useState('');
    const [phone, setPhone] = useState('');

    const isValidEmail = (email) => {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    };

    const formatPhoneNumber = (value) => {
        const digits = value.replace(/\D/g, '').substring(0, 11); // 11자리로 제한
        if (digits.length <= 3) return digits; // 앞자리가 3자리까지는 그냥 반환
        if (digits.length <= 7) {
            return `${digits.slice(0, 3)}-${digits.slice(3)}`; // 3-4자리 하이픈
        }
        return `${digits.slice(0, 3)}-${digits.slice(3, 7)}-${digits.slice(7)}`; // 3-4-4자리 하이픈
    };

    const handlePhoneChange = (e) => {
        const { value } = e.target;
        setPhone(formatPhoneNumber(value)); // 포맷된 전화번호 설정
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        // 비밀번호 확인 검사
        if (pw !== pwc) {
            alert("Passwords do not match.");
            return;
        }

        // 이메일 형식 검사
        if (!isValidEmail(email)) {
            alert("Invalid email format.");
            return;
        }

        

        try {
            // 서버로 데이터 전송
            const response = await axios.post('http://localhost:3001/api/users', {
              email,
              pw,
              phone,
          });
          
          
            console.log('Data saved:', response.data);
            alert('Data saved successfully!');

            // 입력 필드 초기화
            setEmail('');
            setPw('');
            setPwc('');
            setPhone('');
            //성공 시 로그인 페이지
            navigate('/login');
        } catch (error) {
            console.error('Error saving data:', error);
            if (error.response) {
                alert(`Failed to save data: ${error.response.data.message}`);
            } else {
                alert('Failed to save data: Network error');
            }
        }
    };


    return (
        <div className="container">
            <h1 className='login-banner'>Sign Up</h1>
            <form onSubmit={handleSubmit} className="login-form">
                <input
                    className='idpw'
                    type="email"
                    placeholder=" E-mail"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />
                <input
                    className='idpw'
                    type="password"
                    placeholder=" Password"
                    value={pw}
                    onChange={(e) => setPw(e.target.value)}
                />
                <input
                    className='idpw'
                    type="password"
                    placeholder=" Confirm Password"
                    value={pwc}
                    onChange={(e) => setPwc(e.target.value)}
                />
                <input
                    className='idpw'
                    type="text"
                    placeholder=" Phone Number"
                    value={phone}
                    onChange={handlePhoneChange}
                />
                <button type="submit" className='login-button'>완료</button>
            </form>
        </div>
    );
}

export default Signup;
