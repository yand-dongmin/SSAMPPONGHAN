import React, {useState} from 'react';
import './login.css';
import { useNavigate } from 'react-router-dom';


function Login() {
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const navigate = useNavigate(); // 버튼 클릭 시 페이지 이동 라우터

  

  return (
      <div className="container">
        <h1 className='login-banner'>Login</h1>
        <form className="login-form">
                
                <input
                className='idpw'
                type="email"
                placeholder = " E-mail"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                />
                <input
                className='idpw'
                type="password"
                placeholder = " Password"
                value={pw}
                onChange={(e) => setPw(e.target.value)}
                />
        </form>
        <div className='submit-button'>
            <button className='login-button' onClick={() =>{
          navigate('/signup');
        }}>회원가입</button>
            <button className='login-button' onClick={() =>{
          navigate('/');
        }}>로그인</button>
        </div>
      </div>
  );
}

export default Login;
