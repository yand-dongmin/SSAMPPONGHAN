// server/routes/userRoutes.js
const express = require('express');
const router = express.Router();
const User = require('../components/models/users'); // MongoDB의 User 모델

// 회원 가입 데이터 저장을 위한 엔드포인트
router.post('/', async (req, res) => {
    try {
        const { email, pw, phone } = req.body;

        // 새로운 사용자 데이터 생성
        const newUser = new User({
            email,
            password: pw, // 보안을 위해 암호화 필요 (예: bcrypt 사용)
            phone,
        });

        // 데이터베이스에 저장
        await newUser.save();
        res.status(201).json({ message: 'User saved successfully!' });
    } catch (error) {
        console.error('Error saving user:', error);
        res.status(500).json({ message: 'Error saving user to the database' });
    }
});

module.exports = router;
