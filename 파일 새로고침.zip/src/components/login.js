import React, { useState } from 'react';
import './login.css';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Cookies } from 'react-cookie'; // react-cookie 라이브러리에서 Cookies 불러오기

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPw] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate(); // 버튼 클릭 시 페이지 이동 라우터
  const cookies = new Cookies(); // 쿠키 객체 생성

  // 로그인 요청 함수
  const handleLogin = async () => {
    try {
      const response = await axios.post('http://localhost:3001/api/users/login', {
        email,
        password,
      });

      console.log("Server response:", response.data); // 서버 응답 확인
      
      if (response.data.message === "Login successful") {
        // 로그인 성공 시 쿠키에 토큰 저장
        cookies.set('userToken', response.data.token, { path: '/' }); // 쿠키에 토큰 저장
        setMessage("로그인 성공!");
        navigate('/'); // 로그인 성공 시 홈으로 이동
        window.location.reload();
      } else {
        setMessage("로그인 실패. 다시 시도해주세요.");
      }
    } catch (error) {
      setMessage("로그인 실패: " + (error.response?.data?.message || error.message));
    }
  };

  return (
      <div className="container">
        <h1 className='login-banner'>Login</h1>
        <form className="login-form">
                
                <input
                className='idpw'
                type="email"
                placeholder = " E-mail"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                />
                <input
                className='idpw'
                type="password"
                placeholder = " Password"
                value={password}
                onChange={(e) => setPw(e.target.value)}
                />
        </form>
        <div className='submit-button'>
            <button className='login-button' onClick={() =>{
          navigate('/signup');
        }}>회원가입</button>
            <button className='login-button' onClick={handleLogin}>로그인</button>
        </div>
        {message && <p className="message">{message}</p>}
      </div>
  );
}

export default Login;
