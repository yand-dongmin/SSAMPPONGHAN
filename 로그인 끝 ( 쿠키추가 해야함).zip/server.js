require("dotenv").config();

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcryptjs');

const app = express();
app.use(express.json());
app.use(cors()); // CORS 설정

app.get('/favicon.ico', (req, res) => {
  res.sendFile(path.join(__dirname, 'path_to_your_favicon.ico'));
});

// MongoDB 연결 설정
const dbConnect = require("./src/config/dbConnect");
dbConnect();

// 사용자 스키마 정의
const userSchema = new mongoose.Schema({
  email: String,
  password: String,
  phone: String,
});

// 사용자 모델 생성
const User = mongoose.model('User', userSchema);

// 사용자 등록 API
app.post('/api/users', async (req, res) => {
  const { email, password, phone } = req.body;

  // 유효성 검사 추가
  if (!email || !password || !phone) {
    return res.status(400).json({ message: 'All fields are required.' });
  }

  try {
    // 비밀번호 해시화
    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({ email, password: hashedPassword, phone });
    await newUser.save();
    return res.status(201).json({ message: 'User registered successfully!' });
  } catch (error) {
    console.error('Error saving user:', error); // 에러 메시지 출력
    return res.status(500).json({ message: 'Failed to register user' });
  }
});

app.post('/api/users/login', async (req, res) => {
  const { email, password } = req.body;

  // 유효성 검사
  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required.' });
  }

  try {
    // 이메일로 사용자 찾기
    const user = await User.findOne({ email });
    if (!user) {
      console.log('No user found with email:', email);
      return res.status(401).json({ message: 'Invalid email or password.' });
    }

    // bcrypt를 사용해 비밀번호 비교
    const isMatch = await bcrypt.compare(password, user.password);
    console.log("Password match result: ", isMatch); // 비밀번호가 일치하는지 확인

    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid email or password.' });
    }

    // 로그인 성공 응답
    return res.status(200).json({ message: 'Login successful' });
  } catch (error) {
    console.error('Error during login:', error);
    return res.status(500).json({ message: 'Login failed' });
  }
});


// 서버 시작
app.listen(3001, () => {
  console.log('Server is running on http://localhost:3001');
});
