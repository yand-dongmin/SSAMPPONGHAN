import React from 'react';
import './login.css';
import { useNavigate } from 'react-router-dom';


function Signup() {

  const navigate = useNavigate(); // 버튼 클릭 시 페이지 이동 라우터
  
  return (
      <div className="container">
        <h1 className='login-banner'>Sign Up</h1>
        <form className="login-form">
                
                <input
                className='idpw'
                type="text"
                id="username"
                placeholder = "E-mail"
                />
                <input
                className='idpw'
                type="password"
                id="password"
                placeholder = "Password"
                />
                <input
                className='idpw'
                type="password"
                id="password"
                placeholder = "Check the password"
                />
                <input
                className='idpw'
                type="phonenumber"
                id="phonenumber"
                placeholder = "Phone Number"
                />
        </form>
        <div className='submit-button'>
            <button className='login-button' onClick={() =>{
          navigate(-1);
        }}>완료</button>
        </div>
      </div>
  );
}

export default Signup;
