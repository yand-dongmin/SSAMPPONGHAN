import React from 'react';
import './Cart.css'; // CSS 파일 import

function Cart() {
  return (
    <div>
      <h2 className="left-align">장바구니</h2>
      {/* 이미지가 포함될 컨테이너 추가 */}
      <div className="image-container">
        <img src="/images/fuckyou.png" alt="상품 1" className="product-image" />
      </div>
      <p>장바구니에 담은 상품이 없어요.</p>
      <p>상품을 추가해보세요.</p>
    </div>
  );
}

export default Cart;
