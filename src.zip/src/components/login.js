import React from 'react';
import './login.css';
import { useNavigate } from 'react-router-dom';


function Login() {

  const navigate = useNavigate(); // 버튼 클릭 시 페이지 이동 라우터

  return (
      <div className="container">
        <h1 className='login-banner'>Login</h1>
        <form className="login-form">
                
                <input
                className='idpw'
                type="text"
                id="username"
                placeholder = "E-mail"
                />

                
                <input
                className='idpw'
                type="password"
                id="password"
                placeholder = "Password"
                />
        </form>
        <div className='submit-button'>
            <button className='login-button' onClick={() =>{
          navigate('/signup');
        }}>회원가입</button>
            <button className='login-button' onClick={() =>{
          navigate('/');
        }}>로그인</button>
        </div>
      </div>
  );
}

export default Login;
