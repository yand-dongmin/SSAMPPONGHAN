// server/models/User.js
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }, // 실제로는 암호화를 추가해야 함
    phone: { type: String, required: true },
});

const User = mongoose.model('User', userSchema);

module.exports = User;
