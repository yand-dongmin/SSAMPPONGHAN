import React, { useState } from 'react';
import './login.css';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';


function Signup() {

  const navigate = useNavigate(); // 버튼 클릭 시 페이지 이동 라우터
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [pwc, setPwc] = useState('');
  const [phone, setPhone] = useState('');

  const register = () => {
    
  }

  return (
      <div className="container">
        <h1 className='login-banner'>Sign Up</h1>
        <form className="login-form">
                
                <input
                className='idpw'
                type="text"
                id="username"
                placeholder = "E-mail"
                value={email}
                onChange={(e)=>setEmail(e.target.value)}
                />
                <input
                className='idpw'
                type="password"
                id="password"
                placeholder = "Password"
                value={pw}
                onChange={(e)=>setPw(e.target.value)}
                />
                <input
                className='idpw'
                type="password"
                id="password"
                placeholder = "Check the password"
                value={pwc}
                onChange={(e)=>setPwc(e.target.value)}
                />
                <input
                className='idpw'
                type="phonenumber"
                id="phonenumber"
                placeholder = "Phone Number"
                value={phone}
                onChange={(e)=>setPhone(e.target.value)}
                />
        </form>
        <div className='submit-button'>
            <button className='login-button' onClick={() =>{
              register();
        }}>완료</button>
        </div>
      </div>
  );
}

export default Signup;
