import React, { useState } from 'react';
import './signup.css';
import axios from 'axios';

function Signup() {
    const [email, setEmail] = useState('');
    const [pw, setPw] = useState('');
    const [pwc, setPwc] = useState('');
    const [phone, setPhone] = useState('');

    const isValidEmail = (email) => {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        // 비밀번호 확인 검사
        if (pw !== pwc) {
            alert("Passwords do not match.");
            return;
        }

        // 이메일 형식 검사
        if (!isValidEmail(email)) {
            alert("Invalid email format.");
            return;
        }

        console.log({ email, pw, phone }); // 전송할 데이터 로그 출력

        try {
            // 서버로 데이터 전송
            const response = await axios.post('http://localhost:3001/api/users', {
              email,
              pw,
              phone,
          });
          
          
            console.log('Data saved:', response.data);
            alert('Data saved successfully!');

            // 입력 필드 초기화
            setEmail('');
            setPw('');
            setPwc('');
            setPhone('');
        } catch (error) {
            console.error('Error saving data:', error);
            if (error.response) {
                alert(`Failed to save data: ${error.response.data.message}`);
            } else {
                alert('Failed to save data: Network error');
            }
        }
    };

    return (
        <div className="container">
            <h1 className='login-banner'>Sign Up</h1>
            <form onSubmit={handleSubmit} className="login-form">
                <input
                    className='idpw'
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />
                <input
                    className='idpw'
                    type="password"
                    placeholder="Password"
                    value={pw}
                    onChange={(e) => setPw(e.target.value)}
                />
                <input
                    className='idpw'
                    type="password"
                    placeholder="Confirm Password"
                    value={pwc}
                    onChange={(e) => setPwc(e.target.value)}
                />
                <input
                    className='idpw'
                    type="text"
                    placeholder="Phone Number"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                />
                <button type="submit" className='login-button'>완료</button>
            </form>
        </div>
    );
}

export default Signup;
