import React from 'react';


function Shoes() {
  return (
      <div className="container">

            <h1>Shoes</h1>

      </div>
  );
}

export default Shoes;
