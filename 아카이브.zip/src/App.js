// src/App.js
import React, { useEffect, useState, useMemo } from "react";
import "./App.css";
import { Cookies } from "react-cookie";
import { BrowserRouter, Routes, Route, useNavigate } from "react-router-dom";

// 컴포넌트 임포트
import Category from "./components/category";
import OOTD from "./components/ootd";
import Best from "./components/channel/best";
import Outer from "./components/channel/outer";
import Top from "./components/channel/top";
import Bottom from "./components/channel/bottom";
import Shoes from "./components/channel/shoes";
import Login from "./components/login";
import Signup from "./components/signup";
import Footer from "./components/Footer";

function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}

function AppContent() {
  const navigate = useNavigate();

  return (
    <div className="App">
      <div className="container">
        {/* 헤더 영역 */}
        <Header navigate={navigate} />

        {/* 검색 바 및 메뉴 */}
        <div className="top-banner">
          <SearchBar />
          <Menu navigate={navigate} />
        </div>

        <hr />

        {/* 카테고리 컴포넌트 */}
        <Category />

        <hr />

        {/* 라우팅 영역 */}
        <Routes>
          <Route path="/" element={<OOTD />} />
          <Route path="/best" element={<Best />} />
          <Route path="/outer" element={<Outer />} />
          <Route path="/top" element={<Top />} />
          <Route path="/bottom" element={<Bottom />} />
          <Route path="/shoes" element={<Shoes />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
        </Routes>

        <hr />

        {/* 푸터 컴포넌트 */}
        <Footer />
      </div>
    </div>
  );
}

// 헤더 컴포넌트
function Header({ navigate }) {

  const [isLoggedIn, setIsLoggedIn] = useState(false);
  
  // Cookies 객체를 useMemo로 메모이제이션
  const cookies = useMemo(() => new Cookies(), []);

  
  useEffect(() => {
    const token = cookies.get("userToken"); // 'userToken' 쿠키 확인
    setIsLoggedIn(!!token); // 토큰이 존재하면 로그인 상태로 설정
  }, [cookies]);
  

  const handleCookies = () => {
    if (isLoggedIn) {
      cookies.remove("userToken", {path:"/"}); // 로그아웃 처리
      setIsLoggedIn(false);
      navigate("/");
    } else {
      navigate("/login"); // 로그인 페이지로 이동
    }
  };
  

  return (
    <div className="header-container">
      <h1
        className="brand-title"
        onClick={() => {
          navigate("/");
        }}
      >
        SSAMPPONGHAN
      </h1>
      <span
        className="login-btn"
        onClick={(e) => {
          e.stopPropagation();
          handleCookies();
        }}
      >
        {isLoggedIn ? "Sign Out" : "Sign In"}
      </span>

    </div>
  );
}

// 검색 바 컴포넌트
function SearchBar() {
  return (
    <div className="search-container">
      <input
        type="text"
        className="search-input"
        placeholder="Search Word"
      />
      <button className="search-button">
        <img
          src="images/search.png"
          alt="검색 아이콘"
          className="search-icon"
        />
      </button>
    </div>
  );
}

// 메뉴 컴포넌트
function Menu({ navigate }) {
  return (
    <div className="menu-container">
      <button
        className="profile-button"
        onClick={() => {
          navigate("/login");
        }}
      >
        <img
          src="/images/profile.png"
          alt="프로필 아이콘"
          className="profile-icon"
        />
      </button>
      <button className="shopping-button">
        <img
          src="/images/shopping.png"
          alt="장바구니 아이콘"
          className="shopping-icon"
        />
      </button>
    </div>
  );
}

export default App;
